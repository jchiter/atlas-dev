<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="alert alert-warning">
	<?php echo __( 'You are not allowed to access this page.', 'realia' ); ?>
</div><!-- /.alert -->
